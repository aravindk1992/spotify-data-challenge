# Spotify Data Challenge
Spotify data challenge submission by Aravind Kumar Ramesh on March 22- 2016. <br/>
To view the submission please check out the rendered ipython notebook file.
### Folium maps are not rendered by default on github. To view the submission visit https://nbviewer.jupyter.org/github/aravindk1992/spotify-data-challenge/blob/master/Spotify%20Data%20Challenge.ipynb

## Package Requirements
1. scipy
2. numpy
3. pandas
4. folium - for fancy map plots
5. matplotlib
